﻿Imports MySql.Data.MySqlClient

Public Class frmAssignDetails

    Private Sub frmAssignDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load data into ComboBoxes
        LoadSections()
        LoadCoursesWithQuestions()
        LoadAssessmentTypesWithQuestions()
    End Sub

    ' Load sections into ComboBox
    Private Sub LoadSections()
        If DatabaseModule.openconnection() Then
            Dim query As String = "SELECT section_id, section_name FROM sections"
            Dim cmd As New MySqlCommand(query, DatabaseModule.conn)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()
            While reader.Read()
                Dim section = $"{reader("section_id")} - {reader("section_name")}"
                cmbSections.Items.Add(section)
            End While
            reader.Close()
            DatabaseModule.closeconnection()
        End If
    End Sub

    ' Load courses that have linked questions into ComboBox
    Private Sub LoadCoursesWithQuestions()
        If DatabaseModule.openconnection() Then
            Dim query As String = "SELECT DISTINCT c.course_code " &
                              "FROM Courses c " &
                              "JOIN section_assignments sa ON c.course_id = sa.course_id " &
                              "JOIN Questions q ON sa.question_id = q.question_id"
            Dim cmd As New MySqlCommand(query, DatabaseModule.conn)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()
            While reader.Read()
                cmbCourses.Items.Add(reader("course_code").ToString())
            End While
            reader.Close()
            DatabaseModule.closeconnection()
        End If
    End Sub

    ' Load assessment types that have linked questions into ComboBox
    Private Sub LoadAssessmentTypesWithQuestions()
        If DatabaseModule.openconnection() Then
            Dim query As String = "SELECT DISTINCT at.assessment_type_name " &
                              "FROM assessment_types at " &
                              "JOIN section_assignments sa ON at.assessment_type_id = sa.assessment_type_id " &
                              "JOIN Questions q ON sa.question_id = q.question_id"
            Dim cmd As New MySqlCommand(query, DatabaseModule.conn)
            Dim reader As MySqlDataReader = cmd.ExecuteReader()
            While reader.Read()
                cmbAssessmentTypes.Items.Add(reader("assessment_type_name").ToString())
            End While
            reader.Close()
            DatabaseModule.closeconnection()
        End If
    End Sub
    ' Add assignment to DataGridView
    Private Sub btnAddAssignment_Click(sender As Object, e As EventArgs) Handles btnAddAssignment.Click
        Dim Section = cmbSections.SelectedItem.ToString()
        Dim course = cmbCourses.SelectedItem.ToString()
        Dim assessment_Type = cmbAssessmentTypes.SelectedItem.ToString()
        dgvAssignments.Rows.Add(Section, course, assessment_Type)
    End Sub

    ' Remove selected assignment from DataGridView
    Private Sub btnRemoveAssignment_Click(sender As Object, e As EventArgs) Handles btnRemoveAssignment.Click
        For Each row As DataGridViewRow In dgvAssignments.SelectedRows
            dgvAssignments.Rows.Remove(row)
        Next
    End Sub

    ' Save assignments to the database
    Private Sub btnSaveAssignments_Click(sender As Object, e As EventArgs) Handles btnSaveAssignments.Click
        Try
            If DatabaseModule.openconnection() Then
                For Each row As DataGridViewRow In dgvAssignments.Rows
                    If Not row.IsNewRow Then
                        Dim section = row.Cells("Section").Value.ToString().Split("-"c)
                        Dim sectionId = section(0).Trim()
                        Dim course = row.Cells("Course").Value.ToString()
                        Dim assessment_Type = row.Cells("Assessment_Type").Value.ToString()
                        Dim courseId = GetCourseId(course)
                        Dim assessmentTypeId = GetAssessmentTypeId(assessment_Type)

                        Debug.WriteLine($"Section ID: {sectionId}, Course: {course}, Course ID: {courseId}, Assessment Type: {assessment_Type}, Assessment Type ID: {assessmentTypeId}")

                        Dim query As String = "INSERT INTO section_assignments (section_id, course_id, assessment_type_id) " &
                                          "VALUES (@section_id, @course_id, @assessment_type_id)"
                        Dim cmd As New MySqlCommand(query, DatabaseModule.conn)
                        cmd.Parameters.AddWithValue("@section_id", sectionId)
                        cmd.Parameters.AddWithValue("@course_id", courseId)
                        cmd.Parameters.AddWithValue("@assessment_type_id", assessmentTypeId)
                        cmd.ExecuteNonQuery()
                    End If
                Next
                DatabaseModule.closeconnection()
                MessageBox.Show("Assignments saved successfully!")
            End If
        Catch ex As Exception
            MsgBox("section_assignments: " & ex.Message)
        End Try
    End Sub

    ' Helper functions to get IDs from names (adjust with actual DB logic)
    ' Helper functions to get IDs from names (adjust with actual DB logic)
    Private Function GetCourseId(courseCode As String) As Integer
        Dim courseId As Integer = 0
        Try
            If DatabaseModule.openconnection() Then
                Dim query As String = "SELECT course_id FROM Courses WHERE course_code = @CourseCode"
                Dim cmd As New MySqlCommand(query, DatabaseModule.conn)
                cmd.Parameters.AddWithValue("@CourseCode", courseCode)
                Dim result = cmd.ExecuteScalar()
                If result IsNot Nothing Then
                    courseId = Convert.ToInt32(result)
                End If
                DatabaseModule.closeconnection()
            End If
        Catch ex As Exception
            MsgBox("Error fetching Course ID: " & ex.Message)
        End Try
        Return courseId
    End Function

    Private Function GetAssessmentTypeId(assessmentTypeName As String) As Integer
        Dim assessmentTypeId As Integer = 0
        Try
            If DatabaseModule.openconnection() Then
                Dim query As String = "SELECT assessment_type_id FROM AssessmentTypes WHERE assessment_type_name = @AssessmentTypeName"
                Dim cmd As New MySqlCommand(query, DatabaseModule.conn)
                cmd.Parameters.AddWithValue("@AssessmentTypeName", assessmentTypeName)
                Dim result = cmd.ExecuteScalar()
                If result IsNot Nothing Then
                    assessmentTypeId = Convert.ToInt32(result)
                End If
                DatabaseModule.closeconnection()
            End If
        Catch ex As Exception
            MsgBox("Error fetching Assessment Type ID: " & ex.Message)
        End Try
        Return assessmentTypeId
    End Function


End Class