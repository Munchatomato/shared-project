﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTakeExam
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnPrev = New Button()
        txtQuestion = New TextBox()
        GroupBox1 = New GroupBox()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        rbOptionD = New RadioButton()
        rbOptionC = New RadioButton()
        rbOptionB = New RadioButton()
        rbOptionA = New RadioButton()
        btnNext = New Button()
        btnSubmit = New Button()
        lblCourse = New Label()
        lblDate = New Label()
        lblAssessmentType = New Label()
        lblTime = New Label()
        lblStudentName = New Label()
        lblTotalQuestions = New Label()
        lblCurrentQuestion = New Label()
        GroupBox1.SuspendLayout()
        SuspendLayout()
        ' 
        ' btnPrev
        ' 
        btnPrev.Image = My.Resources.Resources.back
        btnPrev.ImageAlign = ContentAlignment.MiddleLeft
        btnPrev.Location = New Point(35, 338)
        btnPrev.Margin = New Padding(3, 2, 3, 2)
        btnPrev.Name = "btnPrev"
        btnPrev.Size = New Size(102, 22)
        btnPrev.TabIndex = 23
        btnPrev.Text = "PREVIOUS "
        btnPrev.UseVisualStyleBackColor = True
        ' 
        ' txtQuestion
        ' 
        txtQuestion.Location = New Point(35, 137)
        txtQuestion.Margin = New Padding(3, 2, 3, 2)
        txtQuestion.Multiline = True
        txtQuestion.Name = "txtQuestion"
        txtQuestion.Size = New Size(323, 70)
        txtQuestion.TabIndex = 17
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(rbOptionD)
        GroupBox1.Controls.Add(rbOptionC)
        GroupBox1.Controls.Add(rbOptionB)
        GroupBox1.Controls.Add(rbOptionA)
        GroupBox1.Location = New Point(33, 212)
        GroupBox1.Margin = New Padding(3, 2, 3, 2)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Padding = New Padding(3, 2, 3, 2)
        GroupBox1.Size = New Size(780, 114)
        GroupBox1.TabIndex = 24
        GroupBox1.TabStop = False
        GroupBox1.Text = "GroupBox1"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(66, 91)
        Label4.Name = "Label4"
        Label4.Size = New Size(15, 15)
        Label4.TabIndex = 37
        Label4.Text = "D"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(66, 68)
        Label3.Name = "Label3"
        Label3.Size = New Size(15, 15)
        Label3.TabIndex = 36
        Label3.Text = "C"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(66, 43)
        Label2.Name = "Label2"
        Label2.Size = New Size(14, 15)
        Label2.TabIndex = 35
        Label2.Text = "B"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(66, 22)
        Label1.Name = "Label1"
        Label1.Size = New Size(15, 15)
        Label1.TabIndex = 34
        Label1.Text = "A"
        ' 
        ' rbOptionD
        ' 
        rbOptionD.AutoSize = True
        rbOptionD.Location = New Point(87, 87)
        rbOptionD.Margin = New Padding(3, 2, 3, 2)
        rbOptionD.Name = "rbOptionD"
        rbOptionD.Size = New Size(97, 19)
        rbOptionD.TabIndex = 3
        rbOptionD.TabStop = True
        rbOptionD.Text = "RadioButton4"
        rbOptionD.UseVisualStyleBackColor = True
        ' 
        ' rbOptionC
        ' 
        rbOptionC.AutoSize = True
        rbOptionC.Location = New Point(87, 64)
        rbOptionC.Margin = New Padding(3, 2, 3, 2)
        rbOptionC.Name = "rbOptionC"
        rbOptionC.Size = New Size(97, 19)
        rbOptionC.TabIndex = 2
        rbOptionC.TabStop = True
        rbOptionC.Text = "RadioButton3"
        rbOptionC.UseVisualStyleBackColor = True
        ' 
        ' rbOptionB
        ' 
        rbOptionB.AutoSize = True
        rbOptionB.Location = New Point(87, 41)
        rbOptionB.Margin = New Padding(3, 2, 3, 2)
        rbOptionB.Name = "rbOptionB"
        rbOptionB.Size = New Size(97, 19)
        rbOptionB.TabIndex = 1
        rbOptionB.TabStop = True
        rbOptionB.Text = "RadioButton2"
        rbOptionB.UseVisualStyleBackColor = True
        ' 
        ' rbOptionA
        ' 
        rbOptionA.AutoSize = True
        rbOptionA.Location = New Point(87, 20)
        rbOptionA.Margin = New Padding(3, 2, 3, 2)
        rbOptionA.Name = "rbOptionA"
        rbOptionA.Size = New Size(97, 19)
        rbOptionA.TabIndex = 0
        rbOptionA.TabStop = True
        rbOptionA.Text = "RadioButton1"
        rbOptionA.UseVisualStyleBackColor = True
        ' 
        ' btnNext
        ' 
        btnNext.Image = My.Resources.Resources._next
        btnNext.ImageAlign = ContentAlignment.MiddleRight
        btnNext.Location = New Point(143, 338)
        btnNext.Margin = New Padding(3, 2, 3, 2)
        btnNext.Name = "btnNext"
        btnNext.Size = New Size(102, 22)
        btnNext.TabIndex = 25
        btnNext.Text = "NEXT "
        btnNext.UseVisualStyleBackColor = True
        ' 
        ' btnSubmit
        ' 
        btnSubmit.Image = My.Resources.Resources.diskette1
        btnSubmit.ImageAlign = ContentAlignment.MiddleLeft
        btnSubmit.Location = New Point(256, 338)
        btnSubmit.Margin = New Padding(3, 2, 3, 2)
        btnSubmit.Name = "btnSubmit"
        btnSubmit.Size = New Size(102, 22)
        btnSubmit.TabIndex = 26
        btnSubmit.Text = "SUBMIT"
        btnSubmit.UseVisualStyleBackColor = True
        ' 
        ' lblCourse
        ' 
        lblCourse.AutoSize = True
        lblCourse.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        lblCourse.Location = New Point(38, 16)
        lblCourse.Name = "lblCourse"
        lblCourse.Size = New Size(50, 17)
        lblCourse.TabIndex = 27
        lblCourse.Text = "Course"
        ' 
        ' lblDate
        ' 
        lblDate.AutoSize = True
        lblDate.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        lblDate.Location = New Point(724, 44)
        lblDate.Name = "lblDate"
        lblDate.Size = New Size(49, 17)
        lblDate.TabIndex = 28
        lblDate.Text = "Date : "
        ' 
        ' lblAssessmentType
        ' 
        lblAssessmentType.AutoSize = True
        lblAssessmentType.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        lblAssessmentType.Location = New Point(38, 31)
        lblAssessmentType.Name = "lblAssessmentType"
        lblAssessmentType.Size = New Size(107, 17)
        lblAssessmentType.TabIndex = 28
        lblAssessmentType.Text = "Assesment Type"
        ' 
        ' lblTime
        ' 
        lblTime.AutoSize = True
        lblTime.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        lblTime.Location = New Point(724, 72)
        lblTime.Name = "lblTime"
        lblTime.Size = New Size(47, 17)
        lblTime.TabIndex = 30
        lblTime.Text = "Time :"
        ' 
        ' lblStudentName
        ' 
        lblStudentName.AutoSize = True
        lblStudentName.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        lblStudentName.Location = New Point(38, 62)
        lblStudentName.Name = "lblStudentName"
        lblStudentName.Size = New Size(104, 17)
        lblStudentName.TabIndex = 31
        lblStudentName.Text = "Student Name :"
        ' 
        ' lblTotalQuestions
        ' 
        lblTotalQuestions.AutoSize = True
        lblTotalQuestions.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        lblTotalQuestions.Location = New Point(38, 87)
        lblTotalQuestions.Name = "lblTotalQuestions"
        lblTotalQuestions.Size = New Size(70, 17)
        lblTotalQuestions.TabIndex = 32
        lblTotalQuestions.Text = "Questions"
        ' 
        ' lblCurrentQuestion
        ' 
        lblCurrentQuestion.AutoSize = True
        lblCurrentQuestion.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        lblCurrentQuestion.Location = New Point(33, 120)
        lblCurrentQuestion.Name = "lblCurrentQuestion"
        lblCurrentQuestion.Size = New Size(118, 17)
        lblCurrentQuestion.TabIndex = 33
        lblCurrentQuestion.Text = "Current Question "
        ' 
        ' frmTakeExam
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(877, 440)
        ControlBox = False
        Controls.Add(lblCurrentQuestion)
        Controls.Add(lblTotalQuestions)
        Controls.Add(lblStudentName)
        Controls.Add(lblTime)
        Controls.Add(lblAssessmentType)
        Controls.Add(lblDate)
        Controls.Add(lblCourse)
        Controls.Add(btnSubmit)
        Controls.Add(btnNext)
        Controls.Add(GroupBox1)
        Controls.Add(btnPrev)
        Controls.Add(txtQuestion)
        Margin = New Padding(3, 2, 3, 2)
        Name = "frmTakeExam"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnPrev As Button
    Friend WithEvents txtQuestion As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbOptionB As RadioButton
    Friend WithEvents rbOptionA As RadioButton
    Friend WithEvents rbOptionD As RadioButton
    Friend WithEvents rbOptionC As RadioButton
    Friend WithEvents btnNext As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents lblCourse As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents lblAssessmentType As Label
    Friend WithEvents lblTime As Label
    Friend WithEvents lblStudentName As Label
    Friend WithEvents lblTotalQuestions As Label
    Friend WithEvents lblCurrentQuestion As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
