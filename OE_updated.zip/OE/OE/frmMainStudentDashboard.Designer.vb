﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMainStudentDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        btnResults = New Button()
        btnExam = New Button()
        Panel2 = New Panel()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        Button1 = New Button()
        Panel1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(btnResults)
        Panel1.Controls.Add(btnExam)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Margin = New Padding(3, 2, 3, 2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(219, 448)
        Panel1.TabIndex = 0
        ' 
        ' btnResults
        ' 
        btnResults.FlatAppearance.BorderSize = 0
        btnResults.FlatStyle = FlatStyle.Flat
        btnResults.Font = New Font("Calibri", 12F, FontStyle.Bold)
        btnResults.Image = My.Resources.Resources.checklist__1_
        btnResults.ImageAlign = ContentAlignment.MiddleLeft
        btnResults.Location = New Point(3, 231)
        btnResults.Margin = New Padding(3, 2, 3, 2)
        btnResults.Name = "btnResults"
        btnResults.Size = New Size(216, 39)
        btnResults.TabIndex = 1
        btnResults.Text = "RESULTS"
        btnResults.UseVisualStyleBackColor = True
        ' 
        ' btnExam
        ' 
        btnExam.BackColor = Color.Transparent
        btnExam.FlatAppearance.BorderSize = 0
        btnExam.FlatStyle = FlatStyle.Flat
        btnExam.Font = New Font("Calibri", 12F, FontStyle.Bold)
        btnExam.Image = My.Resources.Resources.exam
        btnExam.ImageAlign = ContentAlignment.MiddleLeft
        btnExam.Location = New Point(3, 197)
        btnExam.Margin = New Padding(3, 2, 3, 2)
        btnExam.Name = "btnExam"
        btnExam.Size = New Size(216, 31)
        btnExam.TabIndex = 0
        btnExam.Text = "EXAMS"
        btnExam.UseVisualStyleBackColor = False
        ' 
        ' Panel2
        ' 
        Panel2.Dock = DockStyle.Fill
        Panel2.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        Panel2.Location = New Point(219, 0)
        Panel2.Margin = New Padding(3, 2, 3, 2)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(758, 448)
        Panel2.TabIndex = 1
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.student__1_
        PictureBox1.Location = New Point(45, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(100, 89)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Calibri", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(34, 120)
        Label1.Name = "Label1"
        Label1.Size = New Size(120, 33)
        Label1.TabIndex = 3
        Label1.Text = "STUDENT"
        ' 
        ' Button1
        ' 
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Calibri", 12F, FontStyle.Bold)
        Button1.Image = My.Resources.Resources.logout
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(0, 398)
        Button1.Margin = New Padding(3, 2, 3, 2)
        Button1.Name = "Button1"
        Button1.Size = New Size(216, 39)
        Button1.TabIndex = 4
        Button1.Text = "LOG OUT"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' frmMainStudentDashboard
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(977, 448)
        ControlBox = False
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Margin = New Padding(3, 2, 3, 2)
        Name = "frmMainStudentDashboard"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnResults As Button
    Friend WithEvents btnExam As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
End Class
