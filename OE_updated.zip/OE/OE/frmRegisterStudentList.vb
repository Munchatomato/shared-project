﻿Imports MySql.Data.MySqlClient
Public Class frmRegisterStudentList
    Private Sub frmRegisterStudentList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Get_Data()
    End Sub
    Private Sub Get_Data()
        dgwStudentList.Rows.Clear()
        'student_id, section_id, lastname, firstname, middlename, date_of_birth, gender, email_address, contact_no
        Try
            If DatabaseModule.openconnection Then
                Dim query As String = "SELECT * from students"
                Using cmd As New MySqlCommand(query, DatabaseModule.conn)
                    Using reader As MySqlDataReader = cmd.ExecuteReader
                        If reader.HasRows Then
                            While reader.Read
                                Dim student_id As Integer = reader.GetInt32("student_id")
                                Dim section_id As Integer = reader.GetInt32("section_id")
                                Dim lastname As String = reader.GetString("lastname")
                                Dim firstname As String = reader.GetString("firstname")
                                Dim middlename As String = reader.GetString("middlename")
                                Dim date_of_birth As Date = DateTime.Parse(reader("date_of_birth"))
                                Dim gender As String = reader.GetString("gender")
                                Dim email_address As String = reader.GetString("email_address")
                                Dim contact_no As String = reader.GetString("contact_no")

                                dgwStudentList.Rows.Add(student_id, section_id, lastname, firstname, middlename, date_of_birth.ToString("yyyy-MM-dd"), gender, email_address, contact_no)
                            End While
                        End If
                    End Using
                End Using
                DatabaseModule.closeconnection()
            End If
        Catch ex As Exception
            MsgBox("GETTING STUDENT LIST: " & ex.Message)
        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAddNew.Click
        With frmStudentRegistration
            .ShowDialog()
            '.BringToFront()
        End With
    End Sub
End Class