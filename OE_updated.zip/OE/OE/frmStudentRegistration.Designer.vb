﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudentRegistration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        cmbSection = New ComboBox()
        btnRegister = New Button()
        txtLastname = New TextBox()
        txtFirstname = New TextBox()
        txtMiddlename = New TextBox()
        dateOfBirth = New DateTimePicker()
        txtContactNo = New TextBox()
        txtEmail = New TextBox()
        chGender = New CheckedListBox()
        btnBack = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        SuspendLayout()
        ' 
        ' cmbSection
        ' 
        cmbSection.FormattingEnabled = True
        cmbSection.Location = New Point(147, 223)
        cmbSection.Margin = New Padding(3, 2, 3, 2)
        cmbSection.Name = "cmbSection"
        cmbSection.Size = New Size(133, 23)
        cmbSection.TabIndex = 0
        ' 
        ' btnRegister
        ' 
        btnRegister.Location = New Point(422, 349)
        btnRegister.Margin = New Padding(3, 2, 3, 2)
        btnRegister.Name = "btnRegister"
        btnRegister.Size = New Size(82, 22)
        btnRegister.TabIndex = 1
        btnRegister.Text = "REGISTER"
        btnRegister.UseVisualStyleBackColor = True
        ' 
        ' txtLastname
        ' 
        txtLastname.Location = New Point(98, 30)
        txtLastname.Margin = New Padding(3, 2, 3, 2)
        txtLastname.Name = "txtLastname"
        txtLastname.Size = New Size(147, 23)
        txtLastname.TabIndex = 3
        ' 
        ' txtFirstname
        ' 
        txtFirstname.Location = New Point(340, 30)
        txtFirstname.Margin = New Padding(3, 2, 3, 2)
        txtFirstname.Name = "txtFirstname"
        txtFirstname.Size = New Size(147, 23)
        txtFirstname.TabIndex = 4
        ' 
        ' txtMiddlename
        ' 
        txtMiddlename.Location = New Point(602, 31)
        txtMiddlename.Margin = New Padding(3, 2, 3, 2)
        txtMiddlename.Name = "txtMiddlename"
        txtMiddlename.Size = New Size(147, 23)
        txtMiddlename.TabIndex = 5
        ' 
        ' dateOfBirth
        ' 
        dateOfBirth.Location = New Point(146, 103)
        dateOfBirth.Margin = New Padding(3, 2, 3, 2)
        dateOfBirth.Name = "dateOfBirth"
        dateOfBirth.Size = New Size(219, 23)
        dateOfBirth.TabIndex = 6
        ' 
        ' txtContactNo
        ' 
        txtContactNo.Location = New Point(550, 152)
        txtContactNo.Margin = New Padding(3, 2, 3, 2)
        txtContactNo.Name = "txtContactNo"
        txtContactNo.Size = New Size(199, 23)
        txtContactNo.TabIndex = 7
        ' 
        ' txtEmail
        ' 
        txtEmail.Location = New Point(550, 99)
        txtEmail.Margin = New Padding(3, 2, 3, 2)
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(199, 23)
        txtEmail.TabIndex = 8
        ' 
        ' chGender
        ' 
        chGender.FormattingEnabled = True
        chGender.Items.AddRange(New Object() {"Male" & vbTab, "Female"})
        chGender.Location = New Point(147, 153)
        chGender.Margin = New Padding(3, 2, 3, 2)
        chGender.Name = "chGender"
        chGender.Size = New Size(197, 22)
        chGender.TabIndex = 9
        ' 
        ' btnBack
        ' 
        btnBack.Location = New Point(318, 349)
        btnBack.Margin = New Padding(3, 2, 3, 2)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(82, 22)
        btnBack.TabIndex = 10
        btnBack.Text = "BACK"
        btnBack.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label1.ForeColor = SystemColors.Control
        Label1.Location = New Point(3, 33)
        Label1.Name = "Label1"
        Label1.Size = New Size(81, 17)
        Label1.TabIndex = 0
        Label1.Text = "Last Name :"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label2.ForeColor = SystemColors.Control
        Label2.Location = New Point(251, 37)
        Label2.Name = "Label2"
        Label2.Size = New Size(83, 17)
        Label2.TabIndex = 11
        Label2.Text = "First Name :"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label3.ForeColor = SystemColors.Control
        Label3.Location = New Point(497, 37)
        Label3.Name = "Label3"
        Label3.Size = New Size(99, 17)
        Label3.TabIndex = 12
        Label3.Text = "Middle Name :"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label4.ForeColor = SystemColors.Control
        Label4.Location = New Point(33, 109)
        Label4.Name = "Label4"
        Label4.Size = New Size(98, 17)
        Label4.TabIndex = 13
        Label4.Text = "Date Of Birth :"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label5.ForeColor = SystemColors.Control
        Label5.Location = New Point(69, 160)
        Label5.Name = "Label5"
        Label5.Size = New Size(60, 17)
        Label5.TabIndex = 14
        Label5.Text = "Gender :"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label6.ForeColor = SystemColors.Control
        Label6.Location = New Point(484, 107)
        Label6.Name = "Label6"
        Label6.Size = New Size(50, 17)
        Label6.TabIndex = 15
        Label6.Text = "Email :"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label7.ForeColor = SystemColors.Control
        Label7.Location = New Point(424, 160)
        Label7.Name = "Label7"
        Label7.Size = New Size(117, 17)
        Label7.TabIndex = 16
        Label7.Text = "Contact Number :"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label8.ForeColor = SystemColors.Control
        Label8.Location = New Point(64, 227)
        Label8.Name = "Label8"
        Label8.Size = New Size(61, 17)
        Label8.TabIndex = 17
        Label8.Text = "Section :"
        ' 
        ' frmStudentRegistration
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Maroon
        ClientSize = New Size(844, 414)
        ControlBox = False
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnBack)
        Controls.Add(chGender)
        Controls.Add(txtEmail)
        Controls.Add(txtContactNo)
        Controls.Add(dateOfBirth)
        Controls.Add(txtMiddlename)
        Controls.Add(txtFirstname)
        Controls.Add(txtLastname)
        Controls.Add(btnRegister)
        Controls.Add(cmbSection)
        FormBorderStyle = FormBorderStyle.FixedSingle
        Margin = New Padding(3, 2, 3, 2)
        Name = "frmStudentRegistration"
        StartPosition = FormStartPosition.CenterScreen
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents cmbSection As ComboBox
    Friend WithEvents btnRegister As Button
    Friend WithEvents txtLastname As TextBox
    Friend WithEvents txtFirstname As TextBox
    Friend WithEvents txtMiddlename As TextBox
    Friend WithEvents dateOfBirth As DateTimePicker
    Friend WithEvents txtContactNo As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents chGender As CheckedListBox
    Friend WithEvents btnBack As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
End Class
