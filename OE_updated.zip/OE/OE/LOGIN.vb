﻿Imports System.Runtime.CompilerServices

Public Class LOGIN
    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
        Panel1.BackColor = Color.FromArgb(75, 0, 0, 0)
    End Sub

    Private Sub txtUser_MouseHover(sender As Object, e As EventArgs) Handles txtuser.MouseHover
        txtuser.BackColor = Color.LightGray
    End Sub

    Private Sub txtUser_MouseLeave(sender As Object, e As EventArgs) Handles txtuser.MouseLeave
        txtuser.BackColor = Color.White
    End Sub

    Private Sub txtPass_MouseHover(sender As Object, e As EventArgs) Handles txtpass.MouseHover
        txtpass.BackColor = Color.LightGray
    End Sub

    Private Sub txtPass_MouseLeave(sender As Object, e As EventArgs) Handles txtpass.MouseLeave
        txtpass.BackColor = Color.White
    End Sub

    Private Sub LOGIN_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnexit.Click

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub
End Class
