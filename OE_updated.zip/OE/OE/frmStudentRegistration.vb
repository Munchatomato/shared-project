﻿Imports MySql.Data.MySqlClient
Imports MySql.Data
Imports System.Text.RegularExpressions

Public Class frmStudentRegistration

    Private Sub frmStudentRegistration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load sections when the form loads
        LoadSections()
    End Sub

    ' Load sections into the cmbSection combo box
    Private Sub LoadSections()
        Dim query As String = "SELECT * FROM sections"
        Dim dt As New DataTable()

        If DatabaseModule.openconnection() Then
            Using cmd As New MySqlCommand(query, DatabaseModule.conn)
                Using da As New MySqlDataAdapter(cmd)
                    da.Fill(dt)
                End Using
            End Using
            DatabaseModule.closeconnection()
        End If

        cmbSection.DataSource = dt
        cmbSection.DisplayMember = "section_name"
        cmbSection.ValueMember = "section_id"
    End Sub

    ' Register button click event handler
    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Insert_Data()
    End Sub

    ' Function to validate email format
    Private Function IsValidEmail(email As String) As Boolean
        Dim emailPattern As String = "^[^@\s]+@[^@\s]+\.[^@\s]+$"
        Return Regex.IsMatch(email, emailPattern)
    End Function

    ' Function to validate contact number format (example: 10 digits)
    Private Function IsValidContactNumber(contactNo As String) As Boolean
        Dim contactPattern As String = "^\d{11}$"
        Return Regex.IsMatch(contactNo, contactPattern)
    End Function

    ' Insert data into the students table with validation
    Private Sub Insert_Data()
        ' Validate that all required fields are filled
        If String.IsNullOrWhiteSpace(txtLastname.Text) Then
            MessageBox.Show("Please enter the last name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If String.IsNullOrWhiteSpace(txtFirstname.Text) Then
            MessageBox.Show("Please enter the first name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If cmbSection.SelectedIndex = -1 Then
            MessageBox.Show("Please select a section.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If chGender.SelectedIndex = -1 Then
            MessageBox.Show("Please select the gender.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If Not String.IsNullOrWhiteSpace(txtEmail.Text) AndAlso Not IsValidEmail(txtEmail.Text) Then
            MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        If Not String.IsNullOrWhiteSpace(txtContactNo.Text) AndAlso Not IsValidContactNumber(txtContactNo.Text) Then
            MessageBox.Show("Please enter a valid contact number (11 digits).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Prepare the SQL query
        Dim sectionId As Integer = Convert.ToInt32(cmbSection.SelectedValue)
        Dim query As String = "INSERT INTO students (section_id, lastname, firstname, middlename, date_of_birth, gender, email_address, contact_no) " &
                              "VALUES (@section_id, @lastname, @firstname, @middlename, @date_of_birth, @gender, @email_address, @contact_no)"

        Try
            If DatabaseModule.openconnection() Then
                Using cmd As New MySqlCommand(query, DatabaseModule.conn)
                    ' Add parameters to the command
                    cmd.Parameters.AddWithValue("@section_id", sectionId)
                    cmd.Parameters.AddWithValue("@lastname", txtLastname.Text.Trim())
                    cmd.Parameters.AddWithValue("@firstname", txtFirstname.Text.Trim())
                    cmd.Parameters.AddWithValue("@middlename", If(String.IsNullOrEmpty(txtMiddlename.Text.Trim()), DBNull.Value, txtMiddlename.Text.Trim()))
                    cmd.Parameters.AddWithValue("@date_of_birth", dateOfBirth.Value.ToString("yyyy-MM-dd"))
                    cmd.Parameters.AddWithValue("@gender", chGender.SelectedItem.ToString())
                    cmd.Parameters.AddWithValue("@email_address", If(String.IsNullOrEmpty(txtEmail.Text.Trim()), DBNull.Value, txtEmail.Text.Trim()))
                    cmd.Parameters.AddWithValue("@contact_no", If(String.IsNullOrEmpty(txtContactNo.Text.Trim()), DBNull.Value, txtContactNo.Text.Trim()))

                    ' Execute the command
                    cmd.ExecuteNonQuery()
                End Using
                DatabaseModule.closeconnection()

                MessageBox.Show("The student has been successfully registered!", "Registration Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As MySqlException
            MsgBox("MySQL Error: " & ex.Message)
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub

    ' Back button click event handler
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        ' Close the form
        Me.Close()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class