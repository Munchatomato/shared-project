﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAssignDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        cmbSections = New ComboBox()
        cmbCourses = New ComboBox()
        cmbAssessmentTypes = New ComboBox()
        btnAddAssignment = New Button()
        btnRemoveAssignment = New Button()
        btnSaveAssignments = New Button()
        Panel1 = New Panel()
        dgvAssignments = New DataGridView()
        Section = New DataGridViewTextBoxColumn()
        Course = New DataGridViewTextBoxColumn()
        Assessment_Type = New DataGridViewTextBoxColumn()
        Panel1.SuspendLayout()
        CType(dgvAssignments, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' cmbSections
        ' 
        cmbSections.FormattingEnabled = True
        cmbSections.Location = New Point(52, 48)
        cmbSections.Margin = New Padding(3, 2, 3, 2)
        cmbSections.Name = "cmbSections"
        cmbSections.Size = New Size(133, 23)
        cmbSections.TabIndex = 0
        ' 
        ' cmbCourses
        ' 
        cmbCourses.FormattingEnabled = True
        cmbCourses.Location = New Point(52, 74)
        cmbCourses.Margin = New Padding(3, 2, 3, 2)
        cmbCourses.Name = "cmbCourses"
        cmbCourses.Size = New Size(133, 23)
        cmbCourses.TabIndex = 1
        ' 
        ' cmbAssessmentTypes
        ' 
        cmbAssessmentTypes.FormattingEnabled = True
        cmbAssessmentTypes.Location = New Point(52, 99)
        cmbAssessmentTypes.Margin = New Padding(3, 2, 3, 2)
        cmbAssessmentTypes.Name = "cmbAssessmentTypes"
        cmbAssessmentTypes.Size = New Size(133, 23)
        cmbAssessmentTypes.TabIndex = 2
        ' 
        ' btnAddAssignment
        ' 
        btnAddAssignment.BackColor = Color.DarkGray
        btnAddAssignment.FlatAppearance.BorderColor = Color.White
        btnAddAssignment.FlatStyle = FlatStyle.Flat
        btnAddAssignment.Image = My.Resources.Resources.add
        btnAddAssignment.ImageAlign = ContentAlignment.MiddleLeft
        btnAddAssignment.Location = New Point(439, 90)
        btnAddAssignment.Margin = New Padding(3, 2, 3, 2)
        btnAddAssignment.Name = "btnAddAssignment"
        btnAddAssignment.Size = New Size(118, 22)
        btnAddAssignment.TabIndex = 4
        btnAddAssignment.Text = "ADD NEW"
        btnAddAssignment.UseVisualStyleBackColor = False
        ' 
        ' btnRemoveAssignment
        ' 
        btnRemoveAssignment.BackColor = Color.DarkGray
        btnRemoveAssignment.FlatAppearance.BorderColor = Color.White
        btnRemoveAssignment.FlatStyle = FlatStyle.Flat
        btnRemoveAssignment.Image = My.Resources.Resources.bin
        btnRemoveAssignment.ImageAlign = ContentAlignment.MiddleLeft
        btnRemoveAssignment.Location = New Point(563, 90)
        btnRemoveAssignment.Margin = New Padding(3, 2, 3, 2)
        btnRemoveAssignment.Name = "btnRemoveAssignment"
        btnRemoveAssignment.Size = New Size(82, 22)
        btnRemoveAssignment.TabIndex = 5
        btnRemoveAssignment.Text = "DELETE"
        btnRemoveAssignment.UseVisualStyleBackColor = False
        ' 
        ' btnSaveAssignments
        ' 
        btnSaveAssignments.BackColor = Color.DarkGray
        btnSaveAssignments.FlatAppearance.BorderColor = Color.White
        btnSaveAssignments.FlatStyle = FlatStyle.Flat
        btnSaveAssignments.Image = My.Resources.Resources.diskette
        btnSaveAssignments.ImageAlign = ContentAlignment.MiddleLeft
        btnSaveAssignments.Location = New Point(650, 90)
        btnSaveAssignments.Margin = New Padding(3, 2, 3, 2)
        btnSaveAssignments.Name = "btnSaveAssignments"
        btnSaveAssignments.Size = New Size(82, 22)
        btnSaveAssignments.TabIndex = 6
        btnSaveAssignments.Text = "SAVE"
        btnSaveAssignments.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Panel1.Controls.Add(btnSaveAssignments)
        Panel1.Controls.Add(dgvAssignments)
        Panel1.Controls.Add(btnRemoveAssignment)
        Panel1.Controls.Add(btnAddAssignment)
        Panel1.Location = New Point(10, 9)
        Panel1.Margin = New Padding(3, 2, 3, 2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(767, 382)
        Panel1.TabIndex = 7
        ' 
        ' dgvAssignments
        ' 
        dgvAssignments.AllowUserToAddRows = False
        dgvAssignments.AllowUserToDeleteRows = False
        dgvAssignments.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        dgvAssignments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvAssignments.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvAssignments.Columns.AddRange(New DataGridViewColumn() {Section, Course, Assessment_Type})
        dgvAssignments.Location = New Point(41, 122)
        dgvAssignments.Margin = New Padding(3, 2, 3, 2)
        dgvAssignments.Name = "dgvAssignments"
        dgvAssignments.RowHeadersVisible = False
        dgvAssignments.RowHeadersWidth = 51
        dgvAssignments.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvAssignments.Size = New Size(696, 241)
        dgvAssignments.TabIndex = 8
        ' 
        ' Section
        ' 
        Section.HeaderText = "Section"
        Section.MinimumWidth = 6
        Section.Name = "Section"
        ' 
        ' Course
        ' 
        Course.HeaderText = "Course"
        Course.MinimumWidth = 6
        Course.Name = "Course"
        ' 
        ' Assessment_Type
        ' 
        Assessment_Type.HeaderText = "Assessment Type"
        Assessment_Type.MinimumWidth = 6
        Assessment_Type.Name = "Assessment_Type"
        ' 
        ' frmAssignDetails
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Maroon
        ClientSize = New Size(788, 400)
        ControlBox = False
        Controls.Add(cmbAssessmentTypes)
        Controls.Add(cmbCourses)
        Controls.Add(cmbSections)
        Controls.Add(Panel1)
        Margin = New Padding(3, 2, 3, 2)
        Name = "frmAssignDetails"
        WindowState = FormWindowState.Maximized
        Panel1.ResumeLayout(False)
        CType(dgvAssignments, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents cmbSections As ComboBox
    Friend WithEvents cmbCourses As ComboBox
    Friend WithEvents cmbAssessmentTypes As ComboBox
    Friend WithEvents btnAddAssignment As Button
    Friend WithEvents btnRemoveAssignment As Button
    Friend WithEvents btnSaveAssignments As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents dgvAssignments As DataGridView
    Friend WithEvents Section As DataGridViewTextBoxColumn
    Friend WithEvents Course As DataGridViewTextBoxColumn
    Friend WithEvents Assessment_Type As DataGridViewTextBoxColumn
End Class
