﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LOGIN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtuser = New TextBox()
        Label1 = New Label()
        txtpass = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        PictureBox2 = New PictureBox()
        Panel1 = New Panel()
        btnexit = New Button()
        btnclear = New Button()
        btnlogin = New Button()
        PictureBox1 = New PictureBox()
        Label4 = New Label()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtuser
        ' 
        txtuser.Location = New Point(50, 203)
        txtuser.Name = "txtuser"
        txtuser.Size = New Size(292, 23)
        txtuser.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(50, 96)
        Label1.Name = "Label1"
        Label1.Size = New Size(292, 65)
        Label1.TabIndex = 2
        Label1.Text = "WELCOME !"
        ' 
        ' txtpass
        ' 
        txtpass.Location = New Point(50, 260)
        txtpass.Name = "txtpass"
        txtpass.Size = New Size(292, 23)
        txtpass.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label2.Location = New Point(50, 174)
        Label2.Name = "Label2"
        Label2.Size = New Size(85, 17)
        Label2.TabIndex = 4
        Label2.Text = "USERNAME :"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label3.Location = New Point(49, 240)
        Label3.Name = "Label3"
        Label3.Size = New Size(87, 17)
        Label3.TabIndex = 5
        Label3.Text = "PASSWORD :"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
        PictureBox2.Image = My.Resources.Resources.Capture1_removebg_preview
        PictureBox2.Location = New Point(13, 15)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(100, 72)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 6
        PictureBox2.TabStop = False
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        Panel1.BackColor = SystemColors.Control
        Panel1.BackgroundImageLayout = ImageLayout.Stretch
        Panel1.Controls.Add(btnexit)
        Panel1.Controls.Add(btnclear)
        Panel1.Controls.Add(btnlogin)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(PictureBox2)
        Panel1.Controls.Add(txtuser)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(txtpass)
        Panel1.Controls.Add(Label2)
        Panel1.Location = New Point(178, 42)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(387, 407)
        Panel1.TabIndex = 0
        ' 
        ' btnexit
        ' 
        btnexit.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnexit.ForeColor = Color.Black
        btnexit.Location = New Point(267, 303)
        btnexit.Name = "btnexit"
        btnexit.Size = New Size(75, 32)
        btnexit.TabIndex = 10
        btnexit.Text = "Exit"
        btnexit.UseVisualStyleBackColor = True
        ' 
        ' btnclear
        ' 
        btnclear.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnclear.ForeColor = Color.Black
        btnclear.Location = New Point(162, 303)
        btnclear.Name = "btnclear"
        btnclear.Size = New Size(82, 32)
        btnclear.TabIndex = 9
        btnclear.Text = "Clear"
        btnclear.UseVisualStyleBackColor = True
        ' 
        ' btnlogin
        ' 
        btnlogin.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        btnlogin.ForeColor = Color.Black
        btnlogin.Location = New Point(49, 303)
        btnlogin.Name = "btnlogin"
        btnlogin.Size = New Size(86, 32)
        btnlogin.TabIndex = 8
        btnlogin.Text = "Log In"
        btnlogin.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.Image = My.Resources.Resources.Capture2_removebg_preview
        PictureBox1.Location = New Point(267, 15)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(100, 72)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 7
        PictureBox1.TabStop = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold)
        Label4.Location = New Point(213, 9)
        Label4.Name = "Label4"
        Label4.Size = New Size(327, 17)
        Label4.TabIndex = 11
        Label4.Text = "OFFLINE EXAMINATION AND ASSESTMENT SYSTEM"
        ' 
        ' LOGIN
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.Capture
        BackgroundImageLayout = ImageLayout.Center
        ClientSize = New Size(688, 506)
        ControlBox = False
        Controls.Add(Label4)
        Controls.Add(Panel1)
        DoubleBuffered = True
        FormBorderStyle = FormBorderStyle.FixedSingle
        Margin = New Padding(3, 2, 3, 2)
        MaximizeBox = False
        MinimizeBox = False
        Name = "LOGIN"
        ShowIcon = False
        SizeGripStyle = SizeGripStyle.Show
        StartPosition = FormStartPosition.CenterScreen
        WindowState = FormWindowState.Minimized
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents txtuser As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtpass As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnexit As Button
    Friend WithEvents btnclear As Button
    Friend WithEvents btnlogin As Button
    Friend WithEvents Label4 As Label

End Class
