﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnRegisterStudent = New Button()
        btnAssignSections = New Button()
        btnAddQuestion = New Button()
        SuspendLayout()
        ' 
        ' btnRegisterStudent
        ' 
        btnRegisterStudent.Font = New Font("Calibri", 9.75F, FontStyle.Bold)
        btnRegisterStudent.Location = New Point(113, 262)
        btnRegisterStudent.Margin = New Padding(3, 2, 3, 2)
        btnRegisterStudent.Name = "btnRegisterStudent"
        btnRegisterStudent.Size = New Size(179, 33)
        btnRegisterStudent.TabIndex = 0
        btnRegisterStudent.Text = "Register Student"
        btnRegisterStudent.UseVisualStyleBackColor = True
        ' 
        ' btnAssignSections
        ' 
        btnAssignSections.Font = New Font("Calibri", 9.75F, FontStyle.Bold)
        btnAssignSections.Location = New Point(300, 262)
        btnAssignSections.Margin = New Padding(3, 2, 3, 2)
        btnAssignSections.Name = "btnAssignSections"
        btnAssignSections.Size = New Size(117, 33)
        btnAssignSections.TabIndex = 1
        btnAssignSections.Text = "Assign Section"
        btnAssignSections.UseVisualStyleBackColor = True
        ' 
        ' btnAddQuestion
        ' 
        btnAddQuestion.Font = New Font("Calibri", 9.75F, FontStyle.Bold)
        btnAddQuestion.Location = New Point(439, 262)
        btnAddQuestion.Margin = New Padding(3, 2, 3, 2)
        btnAddQuestion.Name = "btnAddQuestion"
        btnAddQuestion.Size = New Size(139, 33)
        btnAddQuestion.TabIndex = 2
        btnAddQuestion.Text = "Add Question "
        btnAddQuestion.UseVisualStyleBackColor = True
        ' 
        ' frmMain
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(700, 338)
        ControlBox = False
        Controls.Add(btnAddQuestion)
        Controls.Add(btnAssignSections)
        Controls.Add(btnRegisterStudent)
        Margin = New Padding(3, 2, 3, 2)
        Name = "frmMain"
        ResumeLayout(False)
    End Sub

    Friend WithEvents btnRegisterStudent As Button
    Friend WithEvents btnAssignSections As Button
    Friend WithEvents btnAddQuestion As Button
End Class
