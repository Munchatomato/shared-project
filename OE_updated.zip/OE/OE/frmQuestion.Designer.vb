﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmQuestion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        cmbAssessmentType = New ComboBox()
        cmbCourse = New ComboBox()
        cmbSection = New ComboBox()
        txtQuestion = New TextBox()
        txtOptionA = New TextBox()
        txtOptionB = New TextBox()
        txtOptionC = New TextBox()
        txtOptionD = New TextBox()
        cmbCorrectAnswer = New ComboBox()
        btnAddQuestion = New Button()
        btnBack = New Button()
        SuspendLayout()
        ' 
        ' cmbAssessmentType
        ' 
        cmbAssessmentType.FormattingEnabled = True
        cmbAssessmentType.Location = New Point(21, 98)
        cmbAssessmentType.Margin = New Padding(3, 2, 3, 2)
        cmbAssessmentType.Name = "cmbAssessmentType"
        cmbAssessmentType.Size = New Size(202, 23)
        cmbAssessmentType.TabIndex = 6
        ' 
        ' cmbCourse
        ' 
        cmbCourse.FormattingEnabled = True
        cmbCourse.Location = New Point(21, 63)
        cmbCourse.Margin = New Padding(3, 2, 3, 2)
        cmbCourse.Name = "cmbCourse"
        cmbCourse.Size = New Size(202, 23)
        cmbCourse.TabIndex = 5
        ' 
        ' cmbSection
        ' 
        cmbSection.FormattingEnabled = True
        cmbSection.Location = New Point(21, 23)
        cmbSection.Margin = New Padding(3, 2, 3, 2)
        cmbSection.Name = "cmbSection"
        cmbSection.Size = New Size(202, 23)
        cmbSection.TabIndex = 4
        ' 
        ' txtQuestion
        ' 
        txtQuestion.Location = New Point(31, 145)
        txtQuestion.Margin = New Padding(3, 2, 3, 2)
        txtQuestion.Multiline = True
        txtQuestion.Name = "txtQuestion"
        txtQuestion.Size = New Size(385, 70)
        txtQuestion.TabIndex = 7
        ' 
        ' txtOptionA
        ' 
        txtOptionA.Location = New Point(32, 226)
        txtOptionA.Margin = New Padding(3, 2, 3, 2)
        txtOptionA.Name = "txtOptionA"
        txtOptionA.Size = New Size(383, 23)
        txtOptionA.TabIndex = 8
        ' 
        ' txtOptionB
        ' 
        txtOptionB.Location = New Point(32, 250)
        txtOptionB.Margin = New Padding(3, 2, 3, 2)
        txtOptionB.Name = "txtOptionB"
        txtOptionB.Size = New Size(383, 23)
        txtOptionB.TabIndex = 9
        ' 
        ' txtOptionC
        ' 
        txtOptionC.Location = New Point(32, 275)
        txtOptionC.Margin = New Padding(3, 2, 3, 2)
        txtOptionC.Name = "txtOptionC"
        txtOptionC.Size = New Size(383, 23)
        txtOptionC.TabIndex = 10
        ' 
        ' txtOptionD
        ' 
        txtOptionD.Location = New Point(32, 300)
        txtOptionD.Margin = New Padding(3, 2, 3, 2)
        txtOptionD.Name = "txtOptionD"
        txtOptionD.Size = New Size(383, 23)
        txtOptionD.TabIndex = 11
        ' 
        ' cmbCorrectAnswer
        ' 
        cmbCorrectAnswer.FormattingEnabled = True
        cmbCorrectAnswer.Items.AddRange(New Object() {"A", "B", "C", "D"})
        cmbCorrectAnswer.Location = New Point(32, 325)
        cmbCorrectAnswer.Margin = New Padding(3, 2, 3, 2)
        cmbCorrectAnswer.Name = "cmbCorrectAnswer"
        cmbCorrectAnswer.Size = New Size(133, 23)
        cmbCorrectAnswer.TabIndex = 12
        ' 
        ' btnAddQuestion
        ' 
        btnAddQuestion.Location = New Point(135, 363)
        btnAddQuestion.Margin = New Padding(3, 2, 3, 2)
        btnAddQuestion.Name = "btnAddQuestion"
        btnAddQuestion.Size = New Size(82, 22)
        btnAddQuestion.TabIndex = 13
        btnAddQuestion.Text = "SAVE"
        btnAddQuestion.UseVisualStyleBackColor = True
        ' 
        ' btnBack
        ' 
        btnBack.Location = New Point(32, 363)
        btnBack.Margin = New Padding(3, 2, 3, 2)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(82, 22)
        btnBack.TabIndex = 14
        btnBack.Text = "BACK"
        btnBack.UseVisualStyleBackColor = True
        ' 
        ' frmQuestion
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Maroon
        ClientSize = New Size(754, 450)
        ControlBox = False
        Controls.Add(btnBack)
        Controls.Add(btnAddQuestion)
        Controls.Add(cmbCorrectAnswer)
        Controls.Add(txtOptionD)
        Controls.Add(txtOptionC)
        Controls.Add(txtOptionB)
        Controls.Add(txtOptionA)
        Controls.Add(txtQuestion)
        Controls.Add(cmbAssessmentType)
        Controls.Add(cmbCourse)
        Controls.Add(cmbSection)
        FormBorderStyle = FormBorderStyle.FixedSingle
        Margin = New Padding(3, 2, 3, 2)
        Name = "frmQuestion"
        StartPosition = FormStartPosition.CenterScreen
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents cmbAssessmentType As ComboBox
    Friend WithEvents cmbCourse As ComboBox
    Friend WithEvents cmbSection As ComboBox
    Friend WithEvents txtQuestion As TextBox
    Friend WithEvents txtOptionA As TextBox
    Friend WithEvents txtOptionB As TextBox
    Friend WithEvents txtOptionC As TextBox
    Friend WithEvents txtOptionD As TextBox
    Friend WithEvents cmbCorrectAnswer As ComboBox
    Friend WithEvents btnAddQuestion As Button
    Friend WithEvents btnBack As Button
End Class
