﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAdminDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Button2 = New Button()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        btnAssess = New Button()
        Button4 = New Button()
        Button3 = New Button()
        btnQuestions = New Button()
        Button1 = New Button()
        btnCourse = New Button()
        dh = New Panel()
        Panel1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Maroon
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(PictureBox1)
        Panel1.Controls.Add(btnAssess)
        Panel1.Controls.Add(Button4)
        Panel1.Controls.Add(Button3)
        Panel1.Controls.Add(btnQuestions)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(btnCourse)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Margin = New Padding(3, 2, 3, 2)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(220, 537)
        Panel1.TabIndex = 0
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.Maroon
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Calibri", 10.8F, FontStyle.Bold)
        Button2.ForeColor = Color.White
        Button2.Image = My.Resources.Resources.logout
        Button2.ImageAlign = ContentAlignment.MiddleLeft
        Button2.Location = New Point(-1, 494)
        Button2.Margin = New Padding(3, 2, 3, 2)
        Button2.Name = "Button2"
        Button2.Size = New Size(211, 31)
        Button2.TabIndex = 8
        Button2.Text = "LOG OUT"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(49, 142)
        Label1.Name = "Label1"
        Label1.Size = New Size(114, 17)
        Label1.TabIndex = 7
        Label1.Text = "ADMINISTRATOR"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.user
        PictureBox1.Location = New Point(52, 35)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(100, 103)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' btnAssess
        ' 
        btnAssess.BackColor = Color.Maroon
        btnAssess.FlatAppearance.BorderSize = 0
        btnAssess.FlatStyle = FlatStyle.Flat
        btnAssess.Font = New Font("Calibri", 10.8F, FontStyle.Bold)
        btnAssess.ForeColor = Color.White
        btnAssess.Image = My.Resources.Resources.folder
        btnAssess.ImageAlign = ContentAlignment.MiddleLeft
        btnAssess.Location = New Point(0, 350)
        btnAssess.Margin = New Padding(3, 2, 3, 2)
        btnAssess.Name = "btnAssess"
        btnAssess.Size = New Size(211, 31)
        btnAssess.TabIndex = 6
        btnAssess.Text = "Assign Sections"
        btnAssess.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.Maroon
        Button4.FlatAppearance.BorderSize = 0
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Calibri", 10.8F, FontStyle.Bold)
        Button4.ForeColor = Color.White
        Button4.Image = My.Resources.Resources.avatar
        Button4.ImageAlign = ContentAlignment.MiddleLeft
        Button4.Location = New Point(-1, 326)
        Button4.Margin = New Padding(3, 2, 3, 2)
        Button4.Name = "Button4"
        Button4.Size = New Size(211, 31)
        Button4.TabIndex = 5
        Button4.Text = "Register Student"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Maroon
        Button3.FlatAppearance.BorderColor = Color.Maroon
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Calibri", 10.8F, FontStyle.Bold)
        Button3.ForeColor = Color.White
        Button3.Image = My.Resources.Resources.dashboard__1_
        Button3.ImageAlign = ContentAlignment.MiddleLeft
        Button3.Location = New Point(3, 207)
        Button3.Margin = New Padding(3, 2, 3, 2)
        Button3.Name = "Button3"
        Button3.Size = New Size(211, 31)
        Button3.TabIndex = 4
        Button3.Text = "Dashboard"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' btnQuestions
        ' 
        btnQuestions.BackColor = Color.Maroon
        btnQuestions.FlatAppearance.BorderSize = 0
        btnQuestions.FlatStyle = FlatStyle.Flat
        btnQuestions.Font = New Font("Calibri", 10.8F, FontStyle.Bold)
        btnQuestions.ForeColor = Color.White
        btnQuestions.Image = My.Resources.Resources.test
        btnQuestions.ImageAlign = ContentAlignment.MiddleLeft
        btnQuestions.Location = New Point(-1, 296)
        btnQuestions.Margin = New Padding(3, 2, 3, 2)
        btnQuestions.Name = "btnQuestions"
        btnQuestions.Size = New Size(211, 31)
        btnQuestions.TabIndex = 3
        btnQuestions.Text = "Questions"
        btnQuestions.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Maroon
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Calibri", 10.8F, FontStyle.Bold)
        Button1.ForeColor = Color.White
        Button1.Image = My.Resources.Resources._class
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(-1, 268)
        Button1.Margin = New Padding(3, 2, 3, 2)
        Button1.Name = "Button1"
        Button1.Size = New Size(211, 31)
        Button1.TabIndex = 2
        Button1.Text = "Section"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' btnCourse
        ' 
        btnCourse.BackColor = Color.Maroon
        btnCourse.FlatAppearance.BorderSize = 0
        btnCourse.FlatStyle = FlatStyle.Flat
        btnCourse.Font = New Font("Calibri", 10.8F, FontStyle.Bold)
        btnCourse.ForeColor = Color.White
        btnCourse.Image = My.Resources.Resources.learning
        btnCourse.ImageAlign = ContentAlignment.MiddleLeft
        btnCourse.Location = New Point(-1, 233)
        btnCourse.Margin = New Padding(3, 2, 3, 2)
        btnCourse.Name = "btnCourse"
        btnCourse.Size = New Size(211, 31)
        btnCourse.TabIndex = 1
        btnCourse.Text = "Course"
        btnCourse.UseVisualStyleBackColor = False
        ' 
        ' dh
        ' 
        dh.Dock = DockStyle.Fill
        dh.Location = New Point(220, 0)
        dh.Margin = New Padding(3, 2, 3, 2)
        dh.Name = "dh"
        dh.Size = New Size(860, 537)
        dh.TabIndex = 1
        ' 
        ' frmAdminDashboard
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1080, 537)
        ControlBox = False
        Controls.Add(dh)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.FixedSingle
        Margin = New Padding(3, 2, 3, 2)
        Name = "frmAdminDashboard"
        StartPosition = FormStartPosition.CenterScreen
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnQuestions As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents btnCourse As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents dh As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents btnAssess As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button2 As Button
End Class
